function y=y3dx2y2_Tdim(theta,phi)
y=sqrt(15/(16*pi))*abs(sin(theta).*sin(theta).*cos(2*phi));