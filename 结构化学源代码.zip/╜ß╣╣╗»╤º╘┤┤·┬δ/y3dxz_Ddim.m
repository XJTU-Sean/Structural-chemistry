function y=y3dxz_Ddim(sigma,theta,phi)
y=sqrt(2)*sigma.*sigma.*exp(-sigma/3).*(sin(theta).*cos(theta).*cos(phi))./(81*sqrt(pi));