function y=y3dyz_Ddim(sigma,theta,phi)
y=sqrt(2)*sigma.*sigma.*exp(-sigma/3).*(sin(theta).*cos(theta).*sin(phi))./(81*sqrt(pi));