function y=y1s(t)
y=4*t.*exp(-2*t)