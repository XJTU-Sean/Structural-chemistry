function y=y2py_Ddim(sigma,theta,phi)
y=sigma.*exp(-sigma/2).*sin(theta).*sin(phi)/(4*sqrt(2*pi));