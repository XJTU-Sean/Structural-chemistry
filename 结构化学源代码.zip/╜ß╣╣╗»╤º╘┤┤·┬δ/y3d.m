function y=y3d(t)
y=8*t.^6.*exp((-2/3)*t)/(81^2*15)