function y=y2p(t)
y=t.^4.*exp(-t)/24;