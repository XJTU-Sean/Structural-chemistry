function y=y2py_Tdim(theta,phi)
y=sqrt(3/(4*pi))*abs(sin(theta).*sin(phi));