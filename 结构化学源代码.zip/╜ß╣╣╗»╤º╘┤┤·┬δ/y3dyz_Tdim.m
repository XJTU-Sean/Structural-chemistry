function y=y3dyz_Tdim(theta,phi)
y=sqrt(15/(4*pi))*abs(sin(theta).*cos(theta).*sin(phi));