function y=y3dxy_Tdim(theta,phi)
y=sqrt(15/(16*pi))*abs(sin(theta).*sin(theta).*sin(2*phi));