function y=y3d2_Tdim(theta)
y=sqrt(5/(16*pi))*abs(3*cos(theta.^2-1));