function y=y2pz_Ddim(sigma,theta)
y=(sigma).*exp(-sigma/2).*cos(theta)/(4*sqrt(2));