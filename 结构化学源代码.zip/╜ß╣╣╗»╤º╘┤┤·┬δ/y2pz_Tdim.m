function y=y2pz_Tdim(theta)
y=sqrt(3/(4*pi))*abs(cos(theta));