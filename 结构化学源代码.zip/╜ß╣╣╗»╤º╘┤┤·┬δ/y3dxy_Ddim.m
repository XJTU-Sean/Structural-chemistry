function y=y3dxy_Ddim(sigma,theta,phi)
y=sqrt(2)*sigma.*sigma.*exp(-sigma/3).*(sin(theta).*sin(theta).*sin(2*phi))./(81*sqrt(pi));