function y=y3dz_Ddim(sigma,theta)
y=sigma.*sigma.*exp(-sigma/3).*(3*cos(theta.^2)-1)/(81*sqrt(6*pi));