function y=y2px_Ddim(sigma,theta,phi)
y=sigma.*exp(-sigma/2).*sin(theta).*cos(phi)/(4*sqrt(2*pi));