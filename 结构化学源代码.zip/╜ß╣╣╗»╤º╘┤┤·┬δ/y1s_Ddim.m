function y=y1s_Ddim(sigma)
y=exp(-sigma)/sqrt(pi);
