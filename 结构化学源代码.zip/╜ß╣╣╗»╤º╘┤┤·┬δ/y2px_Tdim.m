function y=y2px_Tdim(theta,phi)
y=sqrt(3/(4*pi))*abs(sin(theta).*cos(phi));